﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OaktreeAgency.Models
{
    public partial class Admins
    {
        [Required(ErrorMessage = "Please enter ID")]
        [RegularExpression("[0-9]{3}", ErrorMessage = "Last 3 digits of NRIC")]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please enter User ID")]
        [RegularExpression("[0-9]{3}[A-Z]", ErrorMessage = "Last 4 characters of NRIC")]
        public string UserId { get; set; }

        [Required(ErrorMessage = "Please enter Full Name")]
        public string FName { get; set; }

        [Required(ErrorMessage = "Please enter NRIC")]
        [RegularExpression("[A-Z][0-9]{7}[A-Z]", ErrorMessage = "Invalid NRIC")]
        public string NRIC { get; set; }

        [Required(ErrorMessage = "Please enter Email")]
        [EmailAddress(ErrorMessage = "Invalid Email")]
        public string AEmail { get; set; }

        [Required(ErrorMessage = "Please enter ID")]
        [RegularExpression("[0-9]{8}", ErrorMessage = "Invalid Phone Number")]
        public int APhoneNo { get; set; }
        public virtual LoginUsers IdNavigation { get; set; }
    }
}
