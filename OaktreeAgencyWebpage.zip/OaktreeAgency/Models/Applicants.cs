﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OaktreeAgency.Models
{
    public partial class Applicants
    {
        [Required(ErrorMessage = "Please enter ID")]
        [RegularExpression("[0-9]{3}", ErrorMessage = "Last 3 digits of NRIC")]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please enter User ID")]
        [RegularExpression("[0-9]{3}[A-Z]", ErrorMessage = "Last 4 characters of NRIC")]
        public string UserId { get; set; }

        [Required(ErrorMessage = "Please enter Full Name")]
        public string FName { get; set; }

        [Required(ErrorMessage = "Please enter NRIC")]
        [RegularExpression("[A-Z][0-9]{7}[A-Z]", ErrorMessage = "Invalid NRIC")]
        public string NRIC { get; set; }

        [Required(ErrorMessage = "Please enter Email")]
        [EmailAddress(ErrorMessage = "Invalid Email")]
        public string UEmail { get; set; }

        [Required(ErrorMessage = "Please enter ID")]
        [RegularExpression("[0-9]{8}", ErrorMessage = "Invalid Phone Number")]
        public int UPhoneNo { get; set; }

        [Required(ErrorMessage = "Please enter Gender")]
        [RegularExpression("[MF]", ErrorMessage = "Either M or F")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Please enter Birthdate")]
        public DateTime BirthDate { get; set; }

        [Required(ErrorMessage = "Please select Job Title")]
        public string JobTitle { get; set; }

        [Required(ErrorMessage = "Please select Education Level")]
        public string EduLvl { get; set; }

        [Required(ErrorMessage = "Skills cannot be empty!")]
        public string Skills { get; set; }

        [Required(ErrorMessage = "Work Experience cannot be empty!")]
        public string WorkExp { get; set; }

        [Required(ErrorMessage = "Reason of leaving cannot be empty!")]
        public string Leave { get; set; }

        [Required(ErrorMessage = "Last Salary cannot be empty!")]
        public double LastSal { get; set; }

        [Required(ErrorMessage = "Available Date cannot be empty!")]
        public DateTime AvailDate { get; set; }

        public virtual LoginUsers IdNavigation { get; set; }
    }
}
