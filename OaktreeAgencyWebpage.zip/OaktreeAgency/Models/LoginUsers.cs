﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace OaktreeAgency.Models
{
    public partial class LoginUsers
    {
        [Required(ErrorMessage = "Please enter ID")]
        [RegularExpression("[0-9]{3}", ErrorMessage = "Last 3 digits of NRIC")]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please enter User ID")]
        [RegularExpression("[0-9]{3}[A-Z]", ErrorMessage = "Last 4 characters of NRIC")]
        public string UserId { get; set; }

        [Required(ErrorMessage = "Please enter NRIC")]
        [RegularExpression("[A-Z][0-9]{7}[A-Z]", ErrorMessage = "Invalid NRIC")]
        public string NRIC { get; set; }

        [Required(ErrorMessage = "Please enter Full Name")]
        public string FName { get; set; }

        [Required(ErrorMessage = "Please enter Password")]
        [DataType(DataType.Password)]
        public string UserPw { get; set; }

        [Compare("UserPw", ErrorMessage = "Passwords do not match")]
        public string UserPw2 { get; set; }
        public string Role { get; set; }
        public DateTime? LastLogin { get; set; }
        public bool RememberMe { get; set; }
        public virtual Admins Admins { get; set; }
        public virtual Applicants Applicants { get; set; }
    }
}
