using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Security.Claims;
using OaktreeAgency.Models;
using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;

namespace OaktreeAgency.Controllers
{

   public class AccountController : Controller
   {
      private const string LOGIN_SQL =
         @"SELECT * FROM LoginUsers 
            WHERE UserId = '{0}' 
              AND UserPw = HASHBYTES('SHA1', '{1}')";

      private const string LASTLOGIN_SQL =
         @"UPDATE LoginUsers SET LastLogin=GETDATE() WHERE UserId='{0}'";

      private const string ROLE_COL = "Role";
      private const string NAME_COL = "FName";

      private const string REDIRECT_CNTR = "JobApplicant";
      private const string REDIRECT_ACTN = "About";

      private const string LOGIN_VIEW = "Login";

      [AllowAnonymous]
      public IActionResult Login(string returnUrl = null)
      {
         TempData["ReturnUrl"] = returnUrl;
         return View(LOGIN_VIEW);
      }

      [AllowAnonymous]
      [HttpPost]
      public IActionResult Login(LoginUsers user)
      {
            if (!AuthenticateUser(user.UserId, user.UserPw, out ClaimsPrincipal principal))
            {
                ViewData["Message"] = "Incorrect User ID or Password";
                ViewData["MsgType"] = "warning";
                return View(LOGIN_VIEW);
            }
            else
            {
                HttpContext.SignInAsync(
                   CookieAuthenticationDefaults.AuthenticationScheme,
                   principal,
                   new AuthenticationProperties
                   {
                       IsPersistent = user.RememberMe // <--- Here
                   });

                // Update the Last Login Timestamp of the User
                DBUtl.ExecSQL(LASTLOGIN_SQL, user.UserId);

                if (TempData["returnUrl"] != null)
                {
                    string returnUrl = TempData["returnUrl"].ToString();
                    if (Url.IsLocalUrl(returnUrl))
                        return Redirect(returnUrl);
                }

                return RedirectToAction(REDIRECT_ACTN, REDIRECT_CNTR);
            }
        }

      [Authorize]
      public IActionResult Logoff(string returnUrl = null)
      {
         HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
         if (Url.IsLocalUrl(returnUrl))
            return Redirect(returnUrl);
         return RedirectToAction(REDIRECT_ACTN, REDIRECT_CNTR);
      }

      [AllowAnonymous]
      public IActionResult Forbidden()
      {
         return View();
      }

      [AllowAnonymous]
      public IActionResult Register()
      {
         return View("Register");
      }

      [AllowAnonymous]
      [HttpPost]
      public IActionResult Register(LoginUsers usr)
      {
         if (!ModelState.IsValid)
         {
            ViewData["Message"] = "Invalid Input";
            ViewData["MsgType"] = "warning";
            return View("Register");
         }
         else
         {
            string insert =
               @"INSERT INTO LoginUsers(Id, UserId, NRIC, FName, UserPw,  Role) VALUES
                 ('{0}', '{1}', '{2}', '{3}',  HASHBYTES('SHA1', '{4}'), 'Applicant')";
            if (DBUtl.ExecSQL(insert, usr.Id, usr.UserId, usr.NRIC, usr.FName, usr.UserPw, usr.Role) == 1)
            {
                  ViewData["Message"] = "Applicant Successfully Registered";
                  ViewData["MsgType"] = "success";
            }
            else
            {
               ViewData["Message"] = DBUtl.DB_Message;
               ViewData["MsgType"] = "danger";
            }
            return RedirectToAction("Resume", "JobApplicant");
         }
      }

      [AllowAnonymous]
      public IActionResult VerifyUserID(string userId)
      {
         string select = $"SELECT * FROM LoginUsers WHERE Userid='{userId}'";
         if (DBUtl.GetTable(select).Rows.Count > 0)
         {
            return Json($"[{userId}] already in use");
         }
         return Json(true);
      }

      private bool AuthenticateUser(string uid, string pw, out ClaimsPrincipal principal)
      {
         principal = null;

         DataTable ds = DBUtl.GetTable(LOGIN_SQL, uid, pw);
         if (ds.Rows.Count == 1)
         {
            principal =
               new ClaimsPrincipal(
                  new ClaimsIdentity(
                     new Claim[] {
                        new Claim(ClaimTypes.NameIdentifier, uid),
                        new Claim(ClaimTypes.Name, ds.Rows[0][NAME_COL].ToString()),
                        new Claim(ClaimTypes.Role, ds.Rows[0][ROLE_COL].ToString())
                     }, "Basic"
                  )
               );
            return true;
         }
         return false;
      }

      [AllowAnonymous]
      public IActionResult NewApplicant()
      {
         return View("NewApplicant");
      }

      [AllowAnonymous]
      [HttpPost]
      public IActionResult NewApplicant(LoginUsers usr)
        {
            if (!ModelState.IsValid)
            {
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("NewApplicant");
            }
            else
            {
                string insert =
                   @"INSERT INTO LoginUsers(Id, UserId, NRIC, FName, UserPw,  Role) VALUES
                 ('{0}', '{1}', '{2}', '{3}',  HASHBYTES('SHA1', '{4}'), 'Applicant')";
                if (DBUtl.ExecSQL(insert, usr.Id, usr.UserId, usr.NRIC, usr.FName, usr.UserPw, usr.Role) == 1)
                {
                    ViewData["Message"] = "Applicant Successfully Registered";
                    ViewData["MsgType"] = "success";
                }
                else
                {
                    ViewData["Message"] = DBUtl.DB_Message;
                    ViewData["MsgType"] = "danger";
                }
                return RedirectToAction("ApplicantResume", "JobApplicant");
            }
        }

      [AllowAnonymous]
      public IActionResult NewAdmin()
        {
            return View("NewAdmin");
        }

      [AllowAnonymous]
      [HttpPost]
      public IActionResult NewAdmin(LoginUsers usr)
        {
            if (!ModelState.IsValid)
            {
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("NewAdmin");
            }
            else
            {
                string insert =
                   @"INSERT INTO LoginUsers(Id, UserId, NRIC, FName, UserPw,  Role) VALUES
                 ('{0}', '{1}', '{2}', '{3}',  HASHBYTES('SHA1', '{4}'), 'Admin')";
                if (DBUtl.ExecSQL(insert, usr.Id, usr.UserId, usr.NRIC, usr.FName, usr.UserPw, usr.Role) == 1)
                {
                    ViewData["Message"] = "Admin Successfully Registered";
                    ViewData["MsgType"] = "success";
                }
                else
                {
                    ViewData["Message"] = DBUtl.DB_Message;
                    ViewData["MsgType"] = "danger";
                }
               return RedirectToAction("AdminInfo", "JobApplicant");
            }
        }
    }
}