﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OaktreeAgency.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace OaktreeAgency.Controllers
{
    public class JobApplicantController : Controller
    {
        [AllowAnonymous]
        public IActionResult About()
        {
            return View("About");
        }

        [Authorize(Roles = "Admin")]
        public IActionResult AllApplicants()
        {
            List<Applicants> list = DBUtl.GetList<Applicants>("SELECT * FROM Applicants");
            return View(list);
        }

        [Authorize(Roles = "Admin")]
        public IActionResult AllAdmins()
        {
            List<Admins> list = DBUtl.GetList<Admins>("SELECT * FROM Admins");
            return View(list);
        }

        [Authorize(Roles = "Applicant")]
        public IActionResult MyInfo()
        {
            string userid = User.FindFirst(ClaimTypes.NameIdentifier).Value;

            string select = String.Format(@"SELECT * FROM Applicants 
                                          WHERE UserId='{0}'", userid);

            List<Applicants> list = DBUtl.GetList<Applicants>(select);
            return View("MyInfo", list);
        }

        [Authorize(Roles = "Admin")]
        public IActionResult AdminInfo()
        {
            return View("AdminInfo");
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult AdminInfo(Admins ad)
        {
            if (!ModelState.IsValid)
            {
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("AdminInfo");
            }
            else
            {
                string insert =
                   @"INSERT INTO Admins(Id, UserId, FName, NRIC, AEmail, APhoneNo) VALUES
                 ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}')";
                if (DBUtl.ExecSQL(insert, ad.Id, ad.UserId, ad.FName, ad.NRIC, ad.AEmail, ad.APhoneNo) == 1)
                {                   
                        ViewData["Message"] = "Admin Successfully registered";
                        ViewData["MsgType"] = "success";
                    return RedirectToAction("AllAdmins");
                }
                else
                {
                    ViewData["Message"] = DBUtl.DB_Message;
                    ViewData["MsgType"] = "danger";
                    return View("AdminInfo");
                }
               
            }
        }

        [Authorize(Roles = "Admin")]
        public IActionResult ApplicantResume()
        {
            return View("ApplicantResume");
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult ApplicantResume(Applicants app)
        {
            if (!ModelState.IsValid)
            {
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("ApplicantResume");
            }
            else
            {
                string insert =
                   @"INSERT INTO Applicants(Id, UserId, FName, NRIC, UEmail, UPhoneNo, Gender, BirthDate, JobTitle,
                        EduLvl, Skills, WorkExp, Leave, LastSal, AvailDate) VALUES
                 ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7:yyyy-MM-dd}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{14:yyyy-MM-dd}')";
                if (DBUtl.ExecSQL(insert, app.Id, app.UserId, app.FName, app.NRIC, app.UEmail, app.UPhoneNo, app.Gender, app.BirthDate, app.JobTitle, 
                    app.EduLvl, app.Skills, app.WorkExp, app.Leave, app.LastSal, app.AvailDate) == 1)
                {
                    ViewData["Message"] = "Applicants Successfully registered";
                    ViewData["MsgType"] = "success";
                    return RedirectToAction("AllApplicants");
                }
                else
                {
                    ViewData["Message"] = DBUtl.DB_Message;
                    ViewData["MsgType"] = "danger";
                    return View("ApplicantResume");
                }
               
            }
        }

        [Authorize(Roles = "Applicant")]
        public IActionResult Resume()
        {
            return View("Resume");
        }

        [Authorize(Roles = "Applicant")]
        [HttpPost]
        public IActionResult Resume(Applicants app)
        {
            if (!ModelState.IsValid)
            {
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("Resume");
            }
            else
            {
                string insert =
                   @"INSERT INTO Applicants(Id, UserId, FName, NRIC, UEmail, UPhoneNo, Gender, BirthDate, JobTitle,
                        EduLvl, Skills, WorkExp, Leave, LastSal, AvailDate) VALUES
                 ({0}, '{1}', '{2}', '{3}', '{4}', {5}, '{6}', '{7:yyyy-MM-dd}', '{8}', '{9}', '{10}', '{11}', '{12}', {13}, '{14:yyyy-MM-dd}')";
                if (DBUtl.ExecSQL(insert, app.Id, app.UserId, app.FName, app.NRIC, app.UEmail, app.UPhoneNo, app.Gender, app.BirthDate, app.JobTitle,
                    app.EduLvl, app.Skills, app.WorkExp, app.Leave, app.LastSal, app.AvailDate) == 1)
                {
                    ViewData["Message"] = "Applicants Successfully registered";
                    ViewData["MsgType"] = "success";
                    return RedirectToAction("MyInfo");
                }
                else
                {
                    ViewData["Message"] = DBUtl.DB_Message;
                    ViewData["MsgType"] = "danger";
                    return View("Resume");
                }              
            }
        }

        [Authorize(Roles = "Admin")]
        public IActionResult EditAdmin(int id)
        {
            string select = "SELECT * FROM Admins WHERE Id='{0}'";
            List<Admins> list = DBUtl.GetList<Admins>(select, id);
            if (list.Count == 1)
            {
                return View(list[0]);
            }
            else
            {
                TempData["Message"] = "Admin record not found";
                TempData["MsgType"] = "warning";
                return RedirectToAction("AllAdmins");
            }
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult EditAdmin(Admins ad)
        {
            if (!ModelState.IsValid)
            {
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("EditAdmin");
            }
            else
            {
                string update =
                   @"UPDATE Admins
                    SET UserId='{1}', FName='{2}', 
                        NRIC='{3}', AEmail='{4}', APhoneNo='{5}'
                  WHERE Id='{0}'";
                int res = DBUtl.ExecSQL(update, ad.Id, ad.UserId, ad.FName, ad.NRIC, ad.AEmail, ad.APhoneNo);
                if (res == 1)
                {
                    TempData["Message"] = "Admin Updated";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
                return RedirectToAction("AllAdmins");
            }
        }

        [Authorize(Roles = "Admin")]
        public IActionResult EditApplicantResume(int id)
        {
            string select = "SELECT * FROM Applicants WHERE Id='{0}'";
            List<Applicants> list = DBUtl.GetList<Applicants>(select, id);
            if (list.Count == 1)
            {
                return View(list[0]);
            }
            else
            {
                TempData["Message"] = "Applicant record not found";
                TempData["MsgType"] = "warning";
                return RedirectToAction("AllApplicants");
            }
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult EditApplicantResume(Applicants ad)
        {
            if (!ModelState.IsValid)
            {
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("EditApplicantResume");
            }
            else
            {
                string update =
                   @"UPDATE Applicants
                    SET UserId='{1}', FName='{2}', 
                        NRIC='{3}', UEmail='{4}', UPhoneNo={5}, Gender='{6}', BirthDate='{7:yyyy-MM-dd}',
                        JobTitle='{8}', EduLvl='{9}', Skills='{10}', WorkExp='{11}', Leave='{12}',
                        LastSal={13}, AvailDate='{14:yyyy-MM-dd}'
                  WHERE Id='{0}'";
                int res = DBUtl.ExecSQL(update, ad.Id, ad.UserId, ad.FName, ad.NRIC, ad.UEmail, ad.UPhoneNo,
                                            ad.Gender, ad.BirthDate, ad.JobTitle, ad.EduLvl,
                                                ad.Skills, ad.WorkExp, ad.Leave, ad.LastSal,
                                                    ad.AvailDate);
                if (res == 1)
                {
                    TempData["Message"] = "Applicant Updated";
                    TempData["MsgType"] = "success";

                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";

                }
                return RedirectToAction("AllApplicants");
            }
        }

        [Authorize(Roles = "Applicant")]
        public IActionResult EditResume(int id)
        {
            string select = "SELECT * FROM Applicants WHERE Id='{0}'";
            List<Applicants> list = DBUtl.GetList<Applicants>(select, id);
            if (list.Count == 1)
            {
                return View(list[0]);
            }
            else
            {
                TempData["Message"] = "Applicant record not found";
                TempData["MsgType"] = "warning";
                return RedirectToAction("MyInfo");
            }
        }

        [Authorize(Roles = "Applicant")]
        [HttpPost]
        public IActionResult EditResume(Applicants ad)
        {
            if (!ModelState.IsValid)
            {
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("EditResume");
            }
            else
            {
                string update =
                   @"UPDATE Applicants
                    SET UserId='{1}', FName='{2}', 
                        NRIC='{3}', UEmail='{4}', UPhoneNo={5}, Gender='{6}', BirthDate='{7:yyyy-MM-dd}',
                        JobTitle='{8}', EduLvl='{9}', Skills='{10}', WorkExp='{11}', Leave='{12}',
                        LastSal={13}, AvailDate='{14:yyyy-MM-dd}'
                  WHERE Id='{0}'";
                int res = DBUtl.ExecSQL(update, ad.Id, ad.UserId, ad.FName, ad.NRIC, ad.UEmail, ad.UPhoneNo,
                                            ad.Gender, ad.BirthDate, ad.JobTitle, ad.EduLvl,
                                                ad.Skills, ad.WorkExp, ad.Leave, ad.LastSal,
                                                    ad.AvailDate);
                if (res == 1)
                {
                    TempData["Message"] = "Applicant Updated";
                    TempData["MsgType"] = "success";
                   
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                    
                }
                return RedirectToAction("MyInfo");
            }
        }

        [Authorize(Roles = "Admin")]
        public IActionResult DeleteApplicant(int id)
        {
            string select = @"SELECT * FROM Applicants WHERE Id={0}";
            DataTable ds = DBUtl.GetTable(select, id);

            string select1 = @"SELECT * FROM LoginUsers WHERE Id={0}";
            DataTable ds1 = DBUtl.GetTable(select1, id);

            if (ds.Rows.Count != 1 && ds1.Rows.Count != 1)
            {
                TempData["Message"] = "Applicant does not exist";
                TempData["MsgType"] = "warning";
            }
            else
            {
                string delete = "DELETE FROM Applicants WHERE Id={0}";
                int res = DBUtl.ExecSQL(delete, id);

                string delete2 = "DELETE FROM LoginUsers WHERE Id={0}";
                int res2 = DBUtl.ExecSQL(delete2, id);

                if (res == 1 && res2 == 1)
                {
                    TempData["Message"] = "Performance Deleted";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
            }
            return RedirectToAction("AllApplicants");
        }

        [Authorize(Roles = "Admin")]
        public IActionResult DeleteAdmin(int id)
        {
            string select = @"SELECT * FROM Admins WHERE Id={0}";
            DataTable ds = DBUtl.GetTable(select, id);

            string select1 = @"SELECT * FROM LoginUsers WHERE Id={0}";
            DataTable ds1 = DBUtl.GetTable(select1, id);

            if (ds.Rows.Count != 1 && ds1.Rows.Count != 1)
            {
                TempData["Message"] = "Admin does not exist";
                TempData["MsgType"] = "warning";
            }
            else
            {
                string delete = "DELETE FROM Admins WHERE Id={0}";
                int res = DBUtl.ExecSQL(delete, id);

                string delete2 = "DELETE FROM LoginUsers WHERE Id={0}";
                int res2 = DBUtl.ExecSQL(delete2, id);

                if (res == 1 && res2 == 1)
                {
                    TempData["Message"] = "Admin Deleted";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
            }
            return RedirectToAction("AllAdmins");
        }
    }
}
